var ATEditor = (function(ATEditor) {

	ATEditor.settings = ATEditor.settings || {};

	return ATEditor;
})(ATEditor);
